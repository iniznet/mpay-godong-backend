<?php

namespace App\Enums;

enum BalanceStatusEnum: string
{
    case ACTIVE = 'active';
    case INACTIVE = 'inactive';
}
