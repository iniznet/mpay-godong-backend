<?php

namespace App\Enums;

enum UserRoleEnum: string
{
    case ADMIN = 'admin';
    case CUSTOMER = 'customer';
    case COLLECTOR = 'collector';
}
